/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package happytravell.controller;

import happytravell.view.AdmindashboardView;
import happytravell.view.LoginPageView;
import happytravell.view.AdminPlacesView;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


/**
 *
 * @author Acer
 */
public class AdminDashboardController {
    private AdmindashboardView admindashboardView = new AdmindashboardView();
    public AdminDashboardController(AdmindashboardView admindashboardView){
//        this.admindashboardView.LogOutNavigation(new LogOutNav());
        this.admindashboardView.PlacesNavigation(new PlacesNav());
        this.admindashboardView.BookingDetailsNavigation(new AdminDashboardController.BookingDetailsNav(admindashboardView.getBookingDetailslabel()));
        this.admindashboardView.BusTicketsNavigation(new AdminDashboardController.BusTicketsNav(admindashboardView.getBusTicketslabel()));
        this.admindashboardView.RouteDetailsNavigation(new AdminDashboardController.RouteDetailsNav(admindashboardView.getRouteDetailslabel()));
        this.admindashboardView.RouteDetailsNavigation(new AdminDashboardController.RouteDetailsNav(admindashboardView.getProfilelabel()));
        this.admindashboardView.LogOutNavigation(new AdminDashboardController.LogOutNav(admindashboardView.getLogOutlabel()));
        
    }
    
    public void open(){
        this.admindashboardView.setVisible(true);
    } 

    public void close(){
        this.admindashboardView.dispose();
    } 
    
    class BookingDetailsNav implements MouseListener{
        
        private JLabel bookingDetailsLabel;
        
        public ForgetPasswordNav(JLabel label){
            this.bookingDetailsLabel = label;
        }
        
        @Override
        public void mouseClicked(MouseEvent e) {
            ForgetPasswordView forgetPasswordView = new ForgetPasswordView();
            ForgetPasswordController forgetPasswordController= new ForgetPasswordController(forgetPasswordView);
            forgetPasswordController.open();
            close();
        }
        
        @Override
        public void mousePressed(MouseEvent e) {}
        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {
            bookingDetailsLabel.setForeground(Color.BLUE);
            bookingDetailsLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        public void mouseExited(MouseEvent e) {
            bookingDetailsLabel.setForeground(Color.BLACK);
            bookingDetailsLabel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        } 
    }
    


//    class LogOutNav implements ActionListener {
//
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout",
//            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
//
//            if (response == JOptionPane.YES_OPTION) {
//                admindashboardView.dispose();
//
//                LoginPageView loginView = new LoginPageView();
//                LoginController loginController = new LoginController(loginView);
//                loginController.open();
//            }
//        }   
//    }

    class PlacesNav implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
                AdminPlacesView placesView = new AdminPlacesView();
                AdminPlacesController placesController = new AdminPlacesController(placesView);
                placesController.open();
        }
    }   
}
    




